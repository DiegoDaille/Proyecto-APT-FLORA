import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

// Datos de prueba, esto después se trae desde el backend
const misPlantas = [
  { id: 1, nombre: 'Monstera deliciosa', lugar: 'Sala de estar', proximoRiego: 'Hoy' },
  { id: 2, nombre: 'Suculenta Echeveria', lugar: 'Balcón', proximoRiego: '3 días' },
];

const diasSemana = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

export default function HomeScreen({ navigation }) {
  const [racha, setRacha] = useState(12);
  const diaDeHoy = 3; // Jueves, contando desde 0 (L=0)

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.greeting}>Hola, Albert</Text>
        <Text style={styles.subtext}>Tu jardín está bien hoy</Text>

        <View style={styles.mascotCard}>
          <View style={styles.streakPill}>
            <Text style={styles.streakText}>{racha} días</Text>
          </View>
          <View style={styles.cactus} />
          <Text style={styles.mascotName}>Espina</Text>
          <Text style={styles.mascotStatus}>Feliz — regada a tiempo</Text>
        </View>

        <View style={styles.weekRow}>
          {diasSemana.map((dia, index) => (
            <View key={index} style={styles.dayPill}>
              <Text style={styles.dayLabel}>{dia}</Text>
              <View
                style={[
                  styles.dayDot,
                  index < diaDeHoy && styles.dayDotDone,
                  index === diaDeHoy && styles.dayDotToday,
                ]}
              />
            </View>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Mi jardín</Text>
        {misPlantas.map((planta) => (
          <View key={planta.id} style={styles.plantRow}>
            <View style={styles.plantThumb} />
            <View style={styles.plantInfo}>
              <Text style={styles.plantName}>{planta.nombre}</Text>
              <Text style={styles.plantSub}>{planta.lugar}</Text>
            </View>
            <Text style={styles.waterTag}>{planta.proximoRiego}</Text>
          </View>
        ))}

        <TouchableOpacity
          style={styles.scanButton}
          onPress={() => navigation.navigate('Scan')}
        >
          <Text style={styles.scanButtonText}>Escanear planta</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  content: {
    paddingHorizontal: 26,
    paddingTop: 10,
    paddingBottom: 30,
  },
  greeting: {
    fontSize: 22,
    fontWeight: '500',
    color: '#000000',
  },
  subtext: {
    fontSize: 13,
    color: '#c36e9a',
    marginTop: 2,
  },
  mascotCard: {
    backgroundColor: '#7ba44d',
    borderRadius: 20,
    marginTop: 16,
    padding: 22,
    alignItems: 'center',
  },
  streakPill: {
    position: 'absolute',
    top: 14,
    right: 14,
    backgroundColor: '#000000',
    borderRadius: 100,
    paddingHorizontal: 11,
    paddingVertical: 5,
  },
  streakText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  cactus: {
    width: 60,
    height: 70,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginBottom: 8,
    // Nota: esto es un placeholder, hay que reemplazarlo por el
    // dibujo real que está haciendo mi pareja del cactus mascota
  },
  mascotName: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '500',
  },
  mascotStatus: {
    color: '#eef3e6',
    fontSize: 12,
    marginTop: 2,
  },
  weekRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  dayPill: {
    alignItems: 'center',
  },
  dayLabel: {
    fontSize: 10,
    color: '#8a8a8a',
    marginBottom: 6,
  },
  dayDot: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: '#e4a2a3',
    backgroundColor: '#ffffff',
  },
  dayDotDone: {
    backgroundColor: '#7ba44d',
    borderColor: '#7ba44d',
  },
  dayDotToday: {
    borderWidth: 2,
    borderColor: '#c36e9a',
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#000000',
    marginTop: 20,
    marginBottom: 10,
  },
  plantRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fbeef1',
    borderRadius: 14,
    padding: 12,
    marginBottom: 8,
  },
  plantThumb: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: '#7ba44d',
    marginRight: 12,
  },
  plantInfo: {
    flex: 1,
  },
  plantName: {
    fontSize: 13,
    fontWeight: '500',
    color: '#000000',
  },
  plantSub: {
    fontSize: 11,
    color: '#8a8a8a',
    marginTop: 1,
  },
  waterTag: {
    fontSize: 11,
    color: '#c36e9a',
    fontWeight: '600',
  },
  scanButton: {
    marginTop: 20,
    backgroundColor: '#000000',
    borderRadius: 14,
    paddingVertical: 15,
    alignItems: 'center',
  },
  scanButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
});
