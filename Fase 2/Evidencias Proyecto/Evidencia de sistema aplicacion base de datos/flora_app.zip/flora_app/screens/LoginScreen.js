import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { login } from '../services/authService';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cargando, setCargando] = useState(false);

  const handleLogin = async () => {
    if (email === '' || password === '') {
      alert('Completa correo y contraseña');
      return;
    }
    setCargando(true);
    try {
      await login(email, password);
      navigation.navigate('Home');
    } catch (error) {
      alert('No se pudo iniciar sesión');
    } finally {
      setCargando(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.logoRow}>
        <View style={styles.logoMark} />
        <Text style={styles.logoText}>F.L.O.R.A.</Text>
      </View>

      <Text style={styles.title}>Bienvenido{'\n'}de vuelta</Text>
      <Text style={styles.subtitle}>Inicia sesión para ver tu jardín</Text>

      <Text style={styles.label}>Correo electrónico</Text>
      <TextInput
        style={styles.input}
        placeholder="tucorreo@gmail.com"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
      />

      <Text style={styles.label}>Contraseña</Text>
      <TextInput
        style={styles.input}
        placeholder="••••••••"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />

      <TouchableOpacity>
        <Text style={styles.forgot}>¿Olvidaste tu contraseña?</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Iniciar sesión</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={styles.footer}>
          ¿No tienes cuenta? <Text style={styles.footerLink}>Regístrate</Text>
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    paddingHorizontal: 26,
    paddingTop: 20,
  },
  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
  },
  logoMark: {
    width: 38,
    height: 38,
    borderRadius: 11,
    backgroundColor: '#7ba44d',
  },
  logoText: {
    fontSize: 17,
    fontWeight: '600',
    color: '#000000',
    marginLeft: 10,
  },
  title: {
    fontSize: 26,
    color: '#000000',
    marginTop: 30,
    fontWeight: '500',
  },
  subtitle: {
    fontSize: 13,
    color: '#c36e9a',
    marginTop: 6,
  },
  label: {
    fontSize: 12,
    color: '#000000',
    fontWeight: '500',
    marginTop: 20,
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: '#e4a2a3',
    borderRadius: 12,
    padding: 13,
    fontSize: 13,
    color: '#000000',
  },
  forgot: {
    textAlign: 'right',
    fontSize: 12,
    color: '#c36e9a',
    fontWeight: '500',
    marginTop: 10,
  },
  button: {
    marginTop: 22,
    backgroundColor: '#000000',
    borderRadius: 14,
    paddingVertical: 15,
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  footer: {
    marginTop: 26,
    textAlign: 'center',
    fontSize: 12,
    color: '#8a8a8a',
  },
  footerLink: {
    color: '#c36e9a',
    fontWeight: '600',
  },
});
