import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Image } from 'react-native';
import { guardarPlantaEnJardin } from '../services/plantService';

export default function PlantDetailScreen({ route, navigation }) {
  // planta y fotoUri vienen desde ScanScreen tras identificar la foto
  const { planta, fotoUri } = route.params;

  const handleGuardar = async () => {
    await guardarPlantaEnJardin(planta);
    navigation.navigate('Home');
  };

  return (
    <SafeAreaView style={styles.container}>
      {fotoUri ? (
        <Image source={{ uri: fotoUri }} style={styles.photo} />
      ) : (
        <View style={[styles.photo, { backgroundColor: '#7ba44d' }]} />
      )}
      <View style={styles.speciesTag}>
        <Text style={styles.speciesTagText}>{planta.coincidencia}% de coincidencia</Text>
      </View>

      <Text style={styles.title}>{planta.nombre}</Text>
      <Text style={styles.latin}>{planta.nombreCientifico}</Text>

      <View style={styles.careGrid}>
        <View style={styles.careChip}>
          <Text style={styles.careVal}>{planta.riegoSemanal}x</Text>
          <Text style={styles.careLab}>riego/sem</Text>
        </View>
        <View style={styles.careChip}>
          <Text style={styles.careVal}>{planta.luz}</Text>
          <Text style={styles.careLab}>luz</Text>
        </View>
        <View style={styles.careChip}>
          <Text style={styles.careVal}>{planta.temperatura}</Text>
          <Text style={styles.careLab}>temp.</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.cta} onPress={handleGuardar}>
        <Text style={styles.ctaText}>Guardar en mi jardín</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#ffffff', paddingHorizontal: 26, paddingTop: 20 },
  photo: { height: 180, borderRadius: 18, width: '100%' },
  speciesTag: {
    position: 'absolute', top: 172, left: 40, backgroundColor: '#000000',
    borderRadius: 100, paddingHorizontal: 10, paddingVertical: 5,
  },
  speciesTagText: { color: '#ffffff', fontSize: 11, fontWeight: '600' },
  title: { fontSize: 20, color: '#000000', marginTop: 16 },
  latin: { fontSize: 12, fontStyle: 'italic', color: '#c36e9a', marginTop: 2 },
  careGrid: { flexDirection: 'row', gap: 8, marginTop: 16 },
  careChip: { flex: 1, backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#e4a2a3', borderRadius: 14, padding: 10, alignItems: 'center' },
  careVal: { fontSize: 13, fontWeight: '600', color: '#000000' },
  careLab: { fontSize: 10, color: '#8a8a8a', marginTop: 2 },
  cta: { marginTop: 'auto', marginBottom: 20, backgroundColor: '#000000', borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  ctaText: { color: '#ffffff', fontSize: 14, fontWeight: '600' },
});
