import React, { useState, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { identificarPlanta, analizarEntorno } from '../services/plantService';

export default function ScanScreen({ navigation }) {
  const [modo, setModo] = useState('planta'); // 'planta' o 'entorno'
  const [permission, requestPermission] = useCameraPermissions();
  const [cargando, setCargando] = useState(false);
  const cameraRef = useRef(null);

  if (!permission) {
    return <View style={styles.container} />;
  }

  if (!permission.granted) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.hintDark}>Necesitamos permiso de cámara para escanear tu planta</Text>
        <TouchableOpacity style={styles.button} onPress={requestPermission}>
          <Text style={styles.buttonText}>Dar permiso</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  const tomarFoto = async () => {
    if (!cameraRef.current || cargando) return;
    setCargando(true);
    try {
      const foto = await cameraRef.current.takePictureAsync();

      if (modo === 'planta') {
        const resultado = await identificarPlanta(foto.uri);
        navigation.navigate('PlantDetail', { planta: resultado, fotoUri: foto.uri });
      } else {
        const entorno = await analizarEntorno(foto.uri);
        alert(`Entorno: ${entorno.tipo} — ${entorno.apto ? 'Ideal' : 'No ideal'}`);
      }
    } catch (error) {
      console.log('Error al tomar/procesar la foto', error);
      alert('Ocurrió un error, intenta de nuevo');
    } finally {
      setCargando(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Escanear</Text>

      <View style={styles.toggleGroup}>
        <TouchableOpacity
          style={[styles.toggleOpt, modo === 'planta' && styles.toggleOptOn]}
          onPress={() => setModo('planta')}
        >
          <Text style={[styles.toggleText, modo === 'planta' && styles.toggleTextOn]}>Planta</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.toggleOpt, modo === 'entorno' && styles.toggleOptOn]}
          onPress={() => setModo('entorno')}
        >
          <Text style={[styles.toggleText, modo === 'entorno' && styles.toggleTextOn]}>Entorno</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.viewfinder}>
        <CameraView ref={cameraRef} style={StyleSheet.absoluteFill} facing="back" />
      </View>

      <TouchableOpacity style={styles.shutter} onPress={tomarFoto} disabled={cargando}>
        <Text style={{ opacity: 0 }}>.</Text>
      </TouchableOpacity>
      {cargando && <Text style={styles.hintDark}>Analizando...</Text>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#ffffff', paddingHorizontal: 26, paddingTop: 20 },
  title: { fontSize: 19, fontWeight: '500', color: '#000000' },
  toggleGroup: { flexDirection: 'row', backgroundColor: '#f7ecef', borderRadius: 100, padding: 4, marginTop: 14 },
  toggleOpt: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 100 },
  toggleOptOn: { backgroundColor: '#c36e9a' },
  toggleText: { fontSize: 12, fontWeight: '500', color: '#8a8a8a' },
  toggleTextOn: { color: '#ffffff' },
  viewfinder: { flex: 1, marginTop: 16, borderRadius: 20, backgroundColor: '#7ba44d', overflow: 'hidden' },
  shutter: {
    width: 62, height: 62, borderRadius: 31, backgroundColor: '#000000',
    borderWidth: 4, borderColor: '#c36e9a', alignSelf: 'center', marginVertical: 16,
  },
  hintDark: { textAlign: 'center', color: '#000000', marginTop: 10 },
  button: { marginTop: 20, backgroundColor: '#000000', borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  buttonText: { color: '#ffffff', fontWeight: '600' },
});
