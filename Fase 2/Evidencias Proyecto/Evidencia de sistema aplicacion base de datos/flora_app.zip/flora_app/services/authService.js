import api from './api';

// TODO (José / backend): conectar estas funciones con los endpoints
// reales de Django REST Framework cuando estén listos.

export async function login(email, password) {
  // Ejemplo de lo que debería hacer esta función cuando el backend
  // esté listo:
  //
  // const response = await api.post('/auth/login/', { email, password });
  // return response.data; // { token, user }

  console.log('TODO: conectar login real con el backend', email);
  return { token: 'fake-token', user: { nombre: 'Albert' } };
}

export async function register(nombre, email, password) {
  // const response = await api.post('/auth/register/', { nombre, email, password });
  // return response.data;

  console.log('TODO: conectar registro real con el backend');
  return { ok: true };
}

export async function logout() {
  // Limpiar token guardado localmente (AsyncStorage) cuando se implemente
  console.log('TODO: implementar logout');
}
