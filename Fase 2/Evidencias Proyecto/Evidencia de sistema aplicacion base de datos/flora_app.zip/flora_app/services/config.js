// ⚠️ CONFIGURACIÓN DE LA API ⚠️
// Cambien esta URL por la del backend real cuando esté desplegado
// (ej: la URL de Render/Supabase/Vercel del backend en Django).
//
// Mientras desarrollan localmente, usen la IP de su PC en la red
// (no "localhost", porque el celular no la reconoce), ej:
// export const API_BASE_URL = 'http://192.168.1.5:8000/api';

export const API_BASE_URL = 'http://TU_BACKEND_AQUI:8000/api';
