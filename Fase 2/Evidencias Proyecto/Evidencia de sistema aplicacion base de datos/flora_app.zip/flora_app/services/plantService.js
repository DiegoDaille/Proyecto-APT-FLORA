import api from './api';

// TODO (equipo): conectar con el backend real.
// Acá va toda la lógica de: identificar planta, analizar entorno,
// guardar en el jardín del usuario, y consultar/actualizar riego.

export async function identificarPlanta(imagenUri) {
  // Ejemplo real cuando el backend esté listo (multipart/form-data):
  //
  // const formData = new FormData();
  // formData.append('imagen', { uri: imagenUri, name: 'foto.jpg', type: 'image/jpeg' });
  // const response = await api.post('/plantas/identificar/', formData, {
  //   headers: { 'Content-Type': 'multipart/form-data' },
  // });
  // return response.data;

  console.log('TODO: enviar imagen al backend/API de Pl@ntNet', imagenUri);

  // Data de prueba mientras no hay backend conectado
  return {
    nombre: 'Monstera deliciosa',
    nombreCientifico: 'Monstera deliciosa',
    coincidencia: 98,
    riegoSemanal: 2,
    luz: 'Media',
    temperatura: '18-27°',
  };
}

export async function analizarEntorno(imagenUri) {
  // const response = await api.post('/entorno/analizar/', formData, {...});
  // return response.data;

  console.log('TODO: conectar módulo de análisis interior/exterior');
  return { tipo: 'Interior', luz: 'Indirecta', apto: true };
}

export async function obtenerMisPlantas() {
  // const response = await api.get('/plantas/mias/');
  // return response.data;

  console.log('TODO: traer plantas guardadas del usuario desde la BD');
  return [
    { id: 1, nombre: 'Monstera deliciosa', lugar: 'Sala de estar', proximoRiego: 'Hoy' },
    { id: 2, nombre: 'Suculenta Echeveria', lugar: 'Balcón', proximoRiego: '3 días' },
  ];
}

export async function guardarPlantaEnJardin(plantaData) {
  // const response = await api.post('/plantas/', plantaData);
  // return response.data;

  console.log('TODO: guardar nueva planta en la base de datos', plantaData);
  return { ok: true };
}

export async function marcarRiego(plantaId) {
  // const response = await api.post(`/plantas/${plantaId}/regar/`);
  // return response.data;

  console.log('TODO: registrar riego y actualizar racha en el backend', plantaId);
  return { ok: true };
}
